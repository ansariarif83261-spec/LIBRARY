import { useState } from "react";
import { useListIssues, useReturnBook, getListIssuesQueryKey, getListBooksQueryKey, getListMembersQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Undo2, AlertTriangle, CheckCircle, Search } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

function daysDiff(dateStr: string) {
  return Math.ceil((new Date().getTime() - new Date(dateStr).getTime()) / (1000 * 60 * 60 * 24));
}

function estimateFine(dueDate: string): number {
  const now = new Date();
  const due = new Date(dueDate);
  if (now <= due) return 0;
  const daysLate = Math.ceil((now.getTime() - due.getTime()) / (1000 * 60 * 60 * 24));
  return daysLate * 5;
}

export default function ReturnPage() {
  const [search, setSearch] = useState("");
  const [returning, setReturning] = useState<number | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const issues = useListIssues({ status: "issued" });
  const overdueIssues = useListIssues({ status: "overdue" });
  const returnBook = useReturnBook();

  const allActive = [...(issues.data ?? []), ...(overdueIssues.data ?? [])];
  const filtered = search
    ? allActive.filter(i =>
        i.bookTitle.toLowerCase().includes(search.toLowerCase()) ||
        i.memberName.toLowerCase().includes(search.toLowerCase())
      )
    : allActive;

  const handleReturn = (issueId: number) => {
    setReturning(issueId);
    returnBook.mutate({ id: issueId }, {
      onSuccess: (result) => {
        queryClient.invalidateQueries({ queryKey: getListIssuesQueryKey() });
        queryClient.invalidateQueries({ queryKey: getListBooksQueryKey() });
        queryClient.invalidateQueries({ queryKey: getListMembersQueryKey() });
        const fineMsg = result.fineAmount && result.fineAmount > 0 ? ` Fine of ₹${result.fineAmount} generated.` : " No fine.";
        toast({ title: `"${result.bookTitle}" returned successfully`, description: fineMsg });
        setReturning(null);
      },
      onError: () => {
        toast({ title: "Failed to process return", variant: "destructive" });
        setReturning(null);
      },
    });
  };

  return (
    <div className="space-y-5 max-w-3xl">
      <div className="p-4 bg-card border border-card-border rounded-xl shadow-sm">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
            <Undo2 size={16} className="text-primary" />
          </div>
          <div>
            <h3 className="font-semibold text-foreground">Return a Book</h3>
            <p className="text-xs text-muted-foreground">Fine rate: ₹5 per day after due date</p>
          </div>
        </div>
        <div className="relative">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <Input
            data-testid="input-return-search"
            type="search"
            placeholder="Search by book title or member name..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
      </div>

      {issues.isLoading ? (
        <div className="space-y-3">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="bg-card border border-card-border rounded-xl p-5 h-20 animate-pulse" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16 bg-card border border-card-border rounded-xl">
          <CheckCircle size={40} className="mx-auto text-emerald-500 mb-3" />
          <p className="font-medium text-foreground">{search ? "No matching issued books" : "No books currently issued"}</p>
          <p className="text-sm text-muted-foreground mt-1">All books have been returned</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map(issue => {
            const estimatedFine = estimateFine(issue.dueDate);
            const isOverdue = estimatedFine > 0;
            const daysOverdue = isOverdue ? Math.ceil((new Date().getTime() - new Date(issue.dueDate).getTime()) / (1000 * 60 * 60 * 24)) : 0;

            return (
              <div
                key={issue.id}
                className={`bg-card border rounded-xl p-5 shadow-sm ${isOverdue ? "border-amber-200 bg-amber-50/30" : "border-card-border"}`}
                data-testid={`card-return-issue-${issue.id}`}
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      {isOverdue && <AlertTriangle size={14} className="text-amber-500 flex-shrink-0" />}
                      <p className="font-semibold text-foreground text-sm leading-tight truncate">{issue.bookTitle}</p>
                    </div>
                    <p className="text-xs text-muted-foreground">{issue.bookAuthor}</p>
                    <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted-foreground">
                      <span>Member: <strong className="text-foreground">{issue.memberName}</strong></span>
                      <span>Issued: {new Date(issue.issueDate).toLocaleDateString("en-IN")}</span>
                      <span className={isOverdue ? "text-red-500 font-medium" : ""}>
                        Due: {new Date(issue.dueDate).toLocaleDateString("en-IN")}
                        {isOverdue && ` (${daysOverdue}d overdue)`}
                      </span>
                    </div>
                    {isOverdue && (
                      <div className="mt-2 inline-flex items-center gap-1.5 text-xs font-semibold text-amber-700 bg-amber-100 px-2.5 py-1 rounded-full">
                        Estimated fine: ₹{estimatedFine}
                      </div>
                    )}
                  </div>
                  <Button
                    size="sm"
                    onClick={() => handleReturn(issue.id)}
                    disabled={returning === issue.id}
                    data-testid={`button-return-issue-${issue.id}`}
                    className="flex-shrink-0"
                    variant={isOverdue ? "default" : "outline"}
                  >
                    {returning === issue.id ? "Processing..." : "Return"}
                  </Button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
