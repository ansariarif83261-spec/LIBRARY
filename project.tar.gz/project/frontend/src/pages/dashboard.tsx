import { useGetReportSummary, useGetActivityReport, useGetOverdueReport, useGetCategoryStats } from "@workspace/api-client-react";
import { BookOpen, Users, AlertTriangle, IndianRupee, BookCheck, TrendingUp, Clock, CheckCircle } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from "recharts";
import { Link } from "wouter";

function StatCard({ label, value, icon: Icon, color, sub }: { label: string; value: string | number; icon: any; color: string; sub?: string }) {
  return (
    <div className="bg-card border border-card-border rounded-xl p-5 shadow-sm" data-testid={`stat-${label.toLowerCase().replace(/\s/g, "-")}`}>
      <div className="flex items-start justify-between">
        <div>
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">{label}</p>
          <p className="text-2xl font-bold text-foreground mt-1">{value}</p>
          {sub && <p className="text-xs text-muted-foreground mt-1">{sub}</p>}
        </div>
        <div className={`w-10 h-10 rounded-lg ${color} flex items-center justify-center flex-shrink-0`}>
          <Icon size={20} className="text-white" />
        </div>
      </div>
    </div>
  );
}

const ACTIVITY_ICONS: Record<string, any> = {
  issued: BookCheck,
  returned: CheckCircle,
  fine_paid: IndianRupee,
  member_added: Users,
  book_added: BookOpen,
};

const COLORS = ["#1e3a5f", "#3b82f6", "#f59e0b", "#10b981", "#ef4444"];

export default function Dashboard() {
  const summary = useGetReportSummary();
  const activity = useGetActivityReport();
  const overdue = useGetOverdueReport();
  const categoryStats = useGetCategoryStats();

  const s = summary.data;
  const acts = activity.data ?? [];
  const overdueList = overdue.data ?? [];
  const catStats = categoryStats.data ?? [];

  const chartData = catStats.map(c => ({
    name: c.category,
    Available: c.availableBooks,
    Issued: c.issuedBooks,
  }));

  const pieData = [
    { name: "Available", value: s?.availableBooks ?? 0 },
    { name: "Issued", value: s?.issuedBooks ?? 0 },
  ];

  return (
    <div className="space-y-6">
      {/* Overdue Alert */}
      {(s?.overdueBooks ?? 0) > 0 && (
        <div className="flex items-center gap-3 bg-amber-50 border border-amber-200 text-amber-800 rounded-lg px-4 py-3" data-testid="alert-overdue">
          <AlertTriangle size={18} className="flex-shrink-0" />
          <p className="text-sm font-medium">{s?.overdueBooks} book{(s?.overdueBooks ?? 0) > 1 ? "s" : ""} overdue. <Link href="/return" className="underline font-semibold">View and process returns</Link></p>
        </div>
      )}

      {/* Stats Grid */}
      {summary.isLoading ? (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="bg-card border border-card-border rounded-xl p-5 h-24 animate-pulse" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard label="Total Books" value={s?.totalBooks ?? 0} icon={BookOpen} color="bg-blue-900" />
          <StatCard label="Available Books" value={s?.availableBooks ?? 0} icon={BookCheck} color="bg-emerald-600" sub={`${s?.issuedBooks ?? 0} currently issued`} />
          <StatCard label="Total Members" value={s?.totalMembers ?? 0} icon={Users} color="bg-indigo-600" sub={`${s?.activeMembers ?? 0} with active issues`} />
          <StatCard label="Overdue Books" value={s?.overdueBooks ?? 0} icon={AlertTriangle} color="bg-amber-500" />
          <StatCard label="Fines Collected" value={`₹${(s?.totalFinesCollected ?? 0).toFixed(0)}`} icon={IndianRupee} color="bg-green-600" />
          <StatCard label="Pending Fines" value={`₹${(s?.pendingFines ?? 0).toFixed(0)}`} icon={IndianRupee} color="bg-red-500" />
          <StatCard label="Books Issued" value={s?.issuedBooks ?? 0} icon={TrendingUp} color="bg-blue-500" />
          <StatCard label="Active Members" value={s?.activeMembers ?? 0} icon={Users} color="bg-purple-600" />
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Category Chart */}
        <div className="bg-card border border-card-border rounded-xl p-5 shadow-sm">
          <h3 className="font-semibold text-foreground mb-4 text-sm">Books by Category</h3>
          {categoryStats.isLoading ? (
            <div className="h-48 animate-pulse bg-muted rounded" />
          ) : (
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={chartData} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} />
                <Tooltip />
                <Bar dataKey="Available" fill="hsl(var(--chart-1))" radius={[3, 3, 0, 0]} />
                <Bar dataKey="Issued" fill="hsl(var(--chart-3))" radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>

        {/* Pie Chart */}
        <div className="bg-card border border-card-border rounded-xl p-5 shadow-sm">
          <h3 className="font-semibold text-foreground mb-4 text-sm">Book Availability</h3>
          {summary.isLoading ? (
            <div className="h-48 animate-pulse bg-muted rounded" />
          ) : (
            <ResponsiveContainer width="100%" height={220}>
              <PieChart>
                <Pie data={pieData} dataKey="value" cx="50%" cy="50%" outerRadius={80} label={({ name, value }) => `${name}: ${value}`}>
                  {pieData.map((_, index) => (
                    <Cell key={index} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Activity */}
        <div className="bg-card border border-card-border rounded-xl p-5 shadow-sm">
          <h3 className="font-semibold text-foreground mb-4 text-sm">Recent Activity</h3>
          {activity.isLoading ? (
            <div className="space-y-3">{Array.from({ length: 4 }).map((_, i) => <div key={i} className="h-10 bg-muted rounded animate-pulse" />)}</div>
          ) : acts.length === 0 ? (
            <p className="text-sm text-muted-foreground">No recent activity</p>
          ) : (
            <div className="space-y-3">
              {acts.slice(0, 6).map(a => {
                const Icon = ACTIVITY_ICONS[a.type] ?? Clock;
                return (
                  <div key={a.id} className="flex items-start gap-3" data-testid={`activity-item-${a.id}`}>
                    <div className="w-7 h-7 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                      <Icon size={14} className="text-primary" />
                    </div>
                    <div className="min-w-0">
                      <p className="text-sm text-foreground leading-snug">{a.description}</p>
                      <p className="text-xs text-muted-foreground mt-0.5">{new Date(a.timestamp).toLocaleString("en-IN")}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Overdue List */}
        <div className="bg-card border border-card-border rounded-xl p-5 shadow-sm">
          <h3 className="font-semibold text-foreground mb-4 text-sm">Overdue Books</h3>
          {overdue.isLoading ? (
            <div className="space-y-3">{Array.from({ length: 3 }).map((_, i) => <div key={i} className="h-12 bg-muted rounded animate-pulse" />)}</div>
          ) : overdueList.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-6 text-center">
              <CheckCircle size={32} className="text-emerald-500 mb-2" />
              <p className="text-sm font-medium text-foreground">No overdue books</p>
              <p className="text-xs text-muted-foreground">All books returned on time</p>
            </div>
          ) : (
            <div className="space-y-3">
              {overdueList.map(issue => {
                const daysOverdue = Math.ceil((Date.now() - new Date(issue.dueDate).getTime()) / (1000 * 60 * 60 * 24));
                return (
                  <div key={issue.id} className="flex items-center gap-3 p-3 bg-red-50 border border-red-100 rounded-lg" data-testid={`overdue-issue-${issue.id}`}>
                    <AlertTriangle size={16} className="text-red-500 flex-shrink-0" />
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-medium text-foreground truncate">{issue.bookTitle}</p>
                      <p className="text-xs text-muted-foreground">{issue.memberName} · {daysOverdue}d overdue · Est. fine: ₹{daysOverdue * 5}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
