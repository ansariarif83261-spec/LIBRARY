import { useGetMember, useListIssues, useListFines, getGetMemberQueryKey, getListIssuesQueryKey, getListFinesQueryKey } from "@workspace/api-client-react";
import { Link } from "wouter";
import { ArrowLeft, User, BookOpen, IndianRupee, GraduationCap, Phone, Mail, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";

function StatusBadge({ status }: { status: string }) {
  const map: Record<string, string> = {
    issued: "bg-blue-100 text-blue-700",
    returned: "bg-green-100 text-green-700",
    overdue: "bg-red-100 text-red-700",
  };
  return (
    <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${map[status] ?? "bg-muted text-muted-foreground"}`}>
      {status.charAt(0).toUpperCase() + status.slice(1)}
    </span>
  );
}

export default function MemberDetail({ id }: { id: number }) {
  const member = useGetMember(id, { query: { enabled: !!id, queryKey: getGetMemberQueryKey(id) } });
  const issues = useListIssues({ memberId: id }, { query: { enabled: !!id, queryKey: getListIssuesQueryKey({ memberId: id }) } });
  const fines = useListFines({ memberId: id }, { query: { enabled: !!id, queryKey: getListFinesQueryKey({ memberId: id }) } });

  const m = member.data;
  const issueList = issues.data ?? [];
  const fineList = fines.data ?? [];

  return (
    <div className="space-y-5 max-w-3xl">
      <div className="flex items-center gap-3">
        <Link href="/members">
          <a className="p-1.5 rounded-lg hover:bg-muted transition-colors" data-testid="button-back-members">
            <ArrowLeft size={18} />
          </a>
        </Link>
        <h2 className="font-semibold text-foreground">Member Details</h2>
      </div>

      {member.isLoading ? (
        <div className="bg-card border border-card-border rounded-xl p-6 animate-pulse h-36" />
      ) : !m ? (
        <div className="text-center py-12">
          <p className="text-muted-foreground">Member not found</p>
          <Link href="/members"><a className="text-primary text-sm mt-2 inline-block">Back to Members</a></Link>
        </div>
      ) : (
        <>
          <div className="bg-card border border-card-border rounded-xl p-6 shadow-sm">
            <div className="flex items-start gap-4">
              <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                <User size={28} className="text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="text-lg font-bold text-foreground" data-testid="text-member-name">{m.name}</h3>
                <p className="text-sm text-muted-foreground">{m.rollNumber}</p>
                <div className="mt-3 grid grid-cols-1 sm:grid-cols-3 gap-3 text-sm">
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <GraduationCap size={14} />
                    <span className="truncate">{m.classDepartment}</span>
                  </div>
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Phone size={14} />
                    <span>{m.contactNumber}</span>
                  </div>
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Mail size={14} />
                    <span className="truncate">{m.email}</span>
                  </div>
                </div>
                <div className="mt-3 flex items-center gap-4 text-sm">
                  <span className="flex items-center gap-1.5 text-muted-foreground">
                    <BookOpen size={14} />
                    <strong className="text-foreground">{m.booksIssued}</strong> books currently issued
                  </span>
                  <span className="text-muted-foreground">Member since {new Date(m.createdAt).toLocaleDateString("en-IN")}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Issued Books */}
          <div className="bg-card border border-card-border rounded-xl shadow-sm">
            <div className="px-5 py-4 border-b border-border">
              <h3 className="font-semibold text-foreground text-sm">Issue History</h3>
            </div>
            {issues.isLoading ? (
              <div className="p-5 space-y-3">
                {Array.from({ length: 2 }).map((_, i) => <div key={i} className="h-12 bg-muted rounded animate-pulse" />)}
              </div>
            ) : issueList.length === 0 ? (
              <div className="p-8 text-center">
                <BookOpen size={28} className="mx-auto text-muted-foreground mb-2" />
                <p className="text-sm text-muted-foreground">No books issued</p>
              </div>
            ) : (
              <div className="divide-y divide-border">
                {issueList.map(issue => (
                  <div key={issue.id} className="px-5 py-3.5 flex items-center gap-4" data-testid={`row-issue-${issue.id}`}>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-foreground truncate">{issue.bookTitle}</p>
                      <p className="text-xs text-muted-foreground">{issue.bookAuthor}</p>
                    </div>
                    <div className="text-right flex-shrink-0">
                      <StatusBadge status={issue.status} />
                      <p className="text-xs text-muted-foreground mt-1">Due: {new Date(issue.dueDate).toLocaleDateString("en-IN")}</p>
                    </div>
                    {issue.fineAmount && (
                      <span className="text-xs font-medium text-amber-600">₹{issue.fineAmount}</span>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Fines */}
          {fineList.length > 0 && (
            <div className="bg-card border border-card-border rounded-xl shadow-sm">
              <div className="px-5 py-4 border-b border-border">
                <h3 className="font-semibold text-foreground text-sm">Fines</h3>
              </div>
              <div className="divide-y divide-border">
                {fineList.map(fine => (
                  <div key={fine.id} className="px-5 py-3.5 flex items-center gap-4" data-testid={`row-fine-${fine.id}`}>
                    <IndianRupee size={16} className={fine.paid ? "text-green-500" : "text-amber-500"} />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-foreground truncate">{fine.bookTitle}</p>
                      <p className="text-xs text-muted-foreground">Due: {new Date(fine.dueDate).toLocaleDateString("en-IN")} · Returned: {new Date(fine.returnDate).toLocaleDateString("en-IN")}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-bold text-foreground">₹{fine.amount.toFixed(0)}</p>
                      <span className={`text-xs font-medium ${fine.paid ? "text-green-600" : "text-amber-600"}`}>{fine.paid ? "Paid" : "Pending"}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}
