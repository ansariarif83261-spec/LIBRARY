import { useState } from "react";
import { useListMembers, useCreateMember, useDeleteMember, getListMembersQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Plus, Search, Trash2, User, BookOpen, Phone, Mail, GraduationCap } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Link } from "wouter";

const memberSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  rollNumber: z.string().min(1, "Roll number is required"),
  classDepartment: z.string().min(1, "Class/Department is required"),
  contactNumber: z.string().min(10, "Contact number must be at least 10 digits"),
  email: z.string().email("Invalid email address"),
});

type MemberFormData = z.infer<typeof memberSchema>;

export default function Members() {
  const [search, setSearch] = useState("");
  const [open, setOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const members = useListMembers(search ? { search } : undefined);
  const createMember = useCreateMember();
  const deleteMember = useDeleteMember();

  const form = useForm<MemberFormData>({
    resolver: zodResolver(memberSchema),
    defaultValues: { name: "", rollNumber: "", classDepartment: "", contactNumber: "", email: "" },
  });

  const onSubmit = async (data: MemberFormData) => {
    createMember.mutate({ data }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListMembersQueryKey() });
        toast({ title: "Member registered successfully" });
        form.reset();
        setOpen(false);
      },
      onError: () => {
        toast({ title: "Failed to register member", variant: "destructive" });
      },
    });
  };

  const handleDelete = (id: number, name: string) => {
    if (!confirm(`Remove member "${name}"?`)) return;
    deleteMember.mutate({ id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListMembersQueryKey() });
        toast({ title: "Member removed" });
      },
      onError: () => {
        toast({ title: "Failed to remove member", variant: "destructive" });
      },
    });
  };

  const memberList = members.data ?? [];

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between gap-4">
        <div className="relative flex-1 max-w-sm">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <Input
            data-testid="input-member-search"
            type="search"
            placeholder="Search members..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button data-testid="button-add-member" className="gap-2">
              <Plus size={16} />
              Add Member
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Register New Member</DialogTitle>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Full Name</FormLabel>
                      <FormControl>
                        <Input data-testid="input-member-name" placeholder="e.g. Aarav Sharma" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="rollNumber"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Roll Number / Member ID</FormLabel>
                      <FormControl>
                        <Input data-testid="input-member-roll" placeholder="e.g. CS2024001" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="classDepartment"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Class / Department</FormLabel>
                      <FormControl>
                        <Input data-testid="input-member-class" placeholder="e.g. Computer Science - III Year" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="contactNumber"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Contact Number</FormLabel>
                      <FormControl>
                        <Input data-testid="input-member-contact" placeholder="e.g. 9876543210" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email Address</FormLabel>
                      <FormControl>
                        <Input data-testid="input-member-email" type="email" placeholder="e.g. member@college.edu" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <div className="flex gap-3 pt-2">
                  <Button type="button" variant="outline" onClick={() => setOpen(false)} className="flex-1">Cancel</Button>
                  <Button type="submit" disabled={createMember.isPending} className="flex-1" data-testid="button-submit-member">
                    {createMember.isPending ? "Registering..." : "Register"}
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      {members.isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="bg-card border border-card-border rounded-xl p-5 h-32 animate-pulse" />
          ))}
        </div>
      ) : memberList.length === 0 ? (
        <div className="text-center py-16">
          <User size={40} className="mx-auto text-muted-foreground mb-3" />
          <p className="font-medium text-foreground">{search ? "No members found" : "No members registered yet"}</p>
          <p className="text-sm text-muted-foreground mt-1">Add the first member to get started</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {memberList.map(member => (
            <div key={member.id} className="bg-card border border-card-border rounded-xl p-5 shadow-sm hover:shadow-md transition-shadow" data-testid={`card-member-${member.id}`}>
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <User size={18} className="text-primary" />
                  </div>
                  <div className="min-w-0">
                    <Link href={`/members/${member.id}`} data-testid={`link-member-${member.id}`} className="font-semibold text-foreground hover:text-primary transition-colors text-sm leading-tight">{member.name}</Link>
                    <p className="text-xs text-muted-foreground">{member.rollNumber}</p>
                  </div>
                </div>
                <button
                  data-testid={`button-delete-member-${member.id}`}
                  onClick={() => handleDelete(member.id, member.name)}
                  className="p-1.5 rounded-lg hover:bg-destructive/10 hover:text-destructive transition-colors text-muted-foreground"
                >
                  <Trash2 size={15} />
                </button>
              </div>
              <div className="space-y-1.5 text-xs text-muted-foreground">
                <div className="flex items-center gap-2">
                  <GraduationCap size={13} />
                  <span className="truncate">{member.classDepartment}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Phone size={13} />
                  <span>{member.contactNumber}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Mail size={13} />
                  <span className="truncate">{member.email}</span>
                </div>
              </div>
              <div className="mt-3 pt-3 border-t border-border flex items-center gap-2">
                <BookOpen size={13} className="text-muted-foreground" />
                <span className="text-xs text-muted-foreground">{member.booksIssued} book{member.booksIssued !== 1 ? "s" : ""} currently issued</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
