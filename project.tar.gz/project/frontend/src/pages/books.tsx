import { useState } from "react";
import { useListBooks, useCreateBook, useDeleteBook, getListBooksQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Plus, Search, Trash2, BookOpen, Filter } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";

const categories = ["Computer Science", "Mathematics", "Physics", "Chemistry", "Electronics", "Literature", "History", "Economics", "Other"];

const bookSchema = z.object({
  bookId: z.string().min(1, "Book ID is required"),
  title: z.string().min(1, "Title is required"),
  author: z.string().min(1, "Author is required"),
  category: z.string().min(1, "Category is required"),
  totalCopies: z.coerce.number().int().min(1, "At least 1 copy required"),
});

type BookFormData = z.infer<typeof bookSchema>;

export default function Books() {
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState<string>("all");
  const [availableFilter, setAvailableFilter] = useState<string>("all");
  const [open, setOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const params: Record<string, any> = {};
  if (search) params.search = search;
  if (category !== "all") params.category = category;
  if (availableFilter !== "all") params.available = availableFilter === "true";

  const books = useListBooks(Object.keys(params).length > 0 ? params : undefined);
  const createBook = useCreateBook();
  const deleteBook = useDeleteBook();

  const form = useForm<BookFormData>({
    resolver: zodResolver(bookSchema),
    defaultValues: { bookId: "", title: "", author: "", category: "", totalCopies: 1 },
  });

  const onSubmit = async (data: BookFormData) => {
    createBook.mutate({ data }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListBooksQueryKey() });
        toast({ title: "Book added successfully" });
        form.reset();
        setOpen(false);
      },
      onError: () => {
        toast({ title: "Failed to add book", variant: "destructive" });
      },
    });
  };

  const handleDelete = (id: number, title: string) => {
    if (!confirm(`Remove book "${title}"?`)) return;
    deleteBook.mutate({ id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListBooksQueryKey() });
        toast({ title: "Book removed" });
      },
      onError: () => {
        toast({ title: "Failed to remove book", variant: "destructive" });
      },
    });
  };

  const bookList = books.data ?? [];

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-48">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <Input
            data-testid="input-book-search"
            type="search"
            placeholder="Search books..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <Select value={category} onValueChange={setCategory}>
          <SelectTrigger data-testid="select-book-category" className="w-44">
            <SelectValue placeholder="All Categories" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Categories</SelectItem>
            {categories.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={availableFilter} onValueChange={setAvailableFilter}>
          <SelectTrigger data-testid="select-book-availability" className="w-40">
            <SelectValue placeholder="Availability" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Books</SelectItem>
            <SelectItem value="true">Available</SelectItem>
            <SelectItem value="false">Unavailable</SelectItem>
          </SelectContent>
        </Select>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button data-testid="button-add-book" className="gap-2">
              <Plus size={16} />
              Add Book
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Add New Book</DialogTitle>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="bookId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Book ID</FormLabel>
                        <FormControl>
                          <Input data-testid="input-book-id" placeholder="e.g. CS001" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="totalCopies"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Copies</FormLabel>
                        <FormControl>
                          <Input data-testid="input-book-copies" type="number" min={1} {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Book Title</FormLabel>
                      <FormControl>
                        <Input data-testid="input-book-title" placeholder="e.g. Introduction to Algorithms" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="author"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Author</FormLabel>
                      <FormControl>
                        <Input data-testid="input-book-author" placeholder="e.g. Thomas H. Cormen" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="category"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Category</FormLabel>
                      <Select value={field.value} onValueChange={field.onChange}>
                        <FormControl>
                          <SelectTrigger data-testid="select-book-category-form">
                            <SelectValue placeholder="Select category" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {categories.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <div className="flex gap-3 pt-2">
                  <Button type="button" variant="outline" onClick={() => setOpen(false)} className="flex-1">Cancel</Button>
                  <Button type="submit" disabled={createBook.isPending} className="flex-1" data-testid="button-submit-book">
                    {createBook.isPending ? "Adding..." : "Add Book"}
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      {books.isLoading ? (
        <div className="bg-card border border-card-border rounded-xl overflow-hidden">
          {Array.from({ length: 5 }).map((_, i) => (
            <div key={i} className="h-14 border-b border-border animate-pulse bg-muted/30 last:border-0" />
          ))}
        </div>
      ) : bookList.length === 0 ? (
        <div className="text-center py-16">
          <BookOpen size={40} className="mx-auto text-muted-foreground mb-3" />
          <p className="font-medium text-foreground">No books found</p>
          <p className="text-sm text-muted-foreground mt-1">Add your first book to get started</p>
        </div>
      ) : (
        <div className="bg-card border border-card-border rounded-xl overflow-hidden shadow-sm">
          <table className="w-full">
            <thead className="bg-muted/40 border-b border-border">
              <tr>
                <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wide">Book ID</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wide">Title / Author</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wide hidden md:table-cell">Category</th>
                <th className="text-center px-4 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wide">Copies</th>
                <th className="text-center px-4 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wide">Available</th>
                <th className="px-4 py-3"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {bookList.map(book => (
                <tr key={book.id} className="hover:bg-muted/20 transition-colors" data-testid={`row-book-${book.id}`}>
                  <td className="px-4 py-3 text-xs font-mono text-muted-foreground">{book.bookId}</td>
                  <td className="px-4 py-3">
                    <p className="text-sm font-medium text-foreground leading-tight">{book.title}</p>
                    <p className="text-xs text-muted-foreground">{book.author}</p>
                  </td>
                  <td className="px-4 py-3 hidden md:table-cell">
                    <Badge variant="secondary" className="text-xs">{book.category}</Badge>
                  </td>
                  <td className="px-4 py-3 text-center text-sm text-foreground">{book.totalCopies}</td>
                  <td className="px-4 py-3 text-center">
                    <span className={`text-sm font-semibold ${book.availableCopies > 0 ? "text-green-600" : "text-red-500"}`}>
                      {book.availableCopies}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-right">
                    <button
                      data-testid={`button-delete-book-${book.id}`}
                      onClick={() => handleDelete(book.id, book.title)}
                      className="p-1.5 rounded-lg hover:bg-destructive/10 hover:text-destructive transition-colors text-muted-foreground"
                    >
                      <Trash2 size={14} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
