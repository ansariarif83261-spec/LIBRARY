import { useGetReportSummary, useListIssues, useListFines, useGetCategoryStats } from "@workspace/api-client-react";
import { BookOpen, Users, IndianRupee, AlertTriangle, CheckCircle, BookCheck } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from "recharts";

function SectionTitle({ title }: { title: string }) {
  return (
    <h3 className="text-sm font-semibold text-foreground uppercase tracking-wide border-b border-border pb-2 mb-4">{title}</h3>
  );
}

function StatRow({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="flex items-center justify-between py-2 border-b border-border last:border-0">
      <span className="text-sm text-muted-foreground">{label}</span>
      <span className="text-sm font-semibold text-foreground">{value}</span>
    </div>
  );
}

const COLORS = ["#1e3a5f", "#3b82f6", "#f59e0b", "#10b981", "#ef4444", "#8b5cf6"];

export default function Reports() {
  const summary = useGetReportSummary();
  const allIssues = useListIssues();
  const allFines = useListFines();
  const categoryStats = useGetCategoryStats();

  const s = summary.data;
  const issues = allIssues.data ?? [];
  const fines = allFines.data ?? [];
  const catStats = categoryStats.data ?? [];

  const issuedIssues = issues.filter(i => i.status === "issued");
  const returnedIssues = issues.filter(i => i.status === "returned");
  const overdueIssues = issues.filter(i => i.status === "overdue");

  const paidFines = fines.filter(f => f.paid);
  const pendingFines = fines.filter(f => !f.paid);

  const categoryChartData = catStats.map(c => ({
    name: c.category.length > 12 ? c.category.substring(0, 12) + "..." : c.category,
    Available: c.availableBooks,
    Issued: c.issuedBooks,
    Total: c.totalBooks,
  }));

  const issueStatusData = [
    { name: "Active", value: issuedIssues.length },
    { name: "Returned", value: returnedIssues.length },
    { name: "Overdue", value: overdueIssues.length },
  ].filter(d => d.value > 0);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
        {/* Book Report */}
        <div className="bg-card border border-card-border rounded-xl p-5 shadow-sm" data-testid="report-books">
          <div className="flex items-center gap-2 mb-4">
            <BookOpen size={16} className="text-primary" />
            <SectionTitle title="Book Report" />
          </div>
          {summary.isLoading ? <div className="h-20 bg-muted animate-pulse rounded" /> : (
            <div>
              <StatRow label="Total Books" value={s?.totalBooks ?? 0} />
              <StatRow label="Available" value={s?.availableBooks ?? 0} />
              <StatRow label="Currently Issued" value={s?.issuedBooks ?? 0} />
            </div>
          )}
        </div>

        {/* Member Report */}
        <div className="bg-card border border-card-border rounded-xl p-5 shadow-sm" data-testid="report-members">
          <div className="flex items-center gap-2 mb-4">
            <Users size={16} className="text-primary" />
            <SectionTitle title="Member Report" />
          </div>
          {summary.isLoading ? <div className="h-20 bg-muted animate-pulse rounded" /> : (
            <div>
              <StatRow label="Total Members" value={s?.totalMembers ?? 0} />
              <StatRow label="Active Members" value={s?.activeMembers ?? 0} />
              <StatRow label="With No Issues" value={(s?.totalMembers ?? 0) - (s?.activeMembers ?? 0)} />
            </div>
          )}
        </div>

        {/* Issue Report */}
        <div className="bg-card border border-card-border rounded-xl p-5 shadow-sm" data-testid="report-issues">
          <div className="flex items-center gap-2 mb-4">
            <BookCheck size={16} className="text-primary" />
            <SectionTitle title="Issue Report" />
          </div>
          {allIssues.isLoading ? <div className="h-20 bg-muted animate-pulse rounded" /> : (
            <div>
              <StatRow label="Total Issued" value={issues.length} />
              <StatRow label="Returned" value={returnedIssues.length} />
              <StatRow label="Active" value={issuedIssues.length} />
              <StatRow label="Overdue" value={overdueIssues.length} />
            </div>
          )}
        </div>

        {/* Fine Report */}
        <div className="bg-card border border-card-border rounded-xl p-5 shadow-sm" data-testid="report-fines">
          <div className="flex items-center gap-2 mb-4">
            <IndianRupee size={16} className="text-primary" />
            <SectionTitle title="Fine Report" />
          </div>
          {allFines.isLoading ? <div className="h-20 bg-muted animate-pulse rounded" /> : (
            <div>
              <StatRow label="Total Fines" value={fines.length} />
              <StatRow label="Collected" value={`₹${(s?.totalFinesCollected ?? 0).toFixed(0)}`} />
              <StatRow label="Pending" value={`₹${(s?.pendingFines ?? 0).toFixed(0)}`} />
              <StatRow label="Unpaid Count" value={pendingFines.length} />
            </div>
          )}
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-card border border-card-border rounded-xl p-5 shadow-sm">
          <h3 className="font-semibold text-foreground text-sm mb-4">Books by Category</h3>
          {categoryStats.isLoading ? <div className="h-56 bg-muted animate-pulse rounded" /> : (
            <ResponsiveContainer width="100%" height={230}>
              <BarChart data={categoryChartData} margin={{ top: 0, right: 0, left: -20, bottom: 30 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="name" tick={{ fontSize: 10 }} angle={-30} textAnchor="end" />
                <YAxis tick={{ fontSize: 11 }} />
                <Tooltip />
                <Bar dataKey="Available" fill="hsl(var(--chart-1))" radius={[3, 3, 0, 0]} />
                <Bar dataKey="Issued" fill="hsl(var(--chart-3))" radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>

        <div className="bg-card border border-card-border rounded-xl p-5 shadow-sm">
          <h3 className="font-semibold text-foreground text-sm mb-4">Issue Status Distribution</h3>
          {allIssues.isLoading ? <div className="h-56 bg-muted animate-pulse rounded" /> : issueStatusData.length === 0 ? (
            <div className="h-56 flex items-center justify-center text-muted-foreground text-sm">No issue data available</div>
          ) : (
            <ResponsiveContainer width="100%" height={230}>
              <PieChart>
                <Pie data={issueStatusData} dataKey="value" cx="50%" cy="50%" outerRadius={80} label={({ name, value }) => `${name}: ${value}`}>
                  {issueStatusData.map((_, index) => (
                    <Cell key={index} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>

      {/* Detailed Tables */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Issued Books */}
        <div className="bg-card border border-card-border rounded-xl shadow-sm">
          <div className="px-5 py-4 border-b border-border flex items-center justify-between">
            <h3 className="font-semibold text-foreground text-sm">Currently Issued</h3>
            <span className="text-xs text-muted-foreground">{issuedIssues.length} records</span>
          </div>
          <div className="divide-y divide-border max-h-64 overflow-y-auto">
            {issuedIssues.length === 0 ? (
              <div className="p-6 text-center text-sm text-muted-foreground">No active issues</div>
            ) : issuedIssues.map(issue => (
              <div key={issue.id} className="px-5 py-3 flex items-center gap-3" data-testid={`report-issue-${issue.id}`}>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground truncate">{issue.bookTitle}</p>
                  <p className="text-xs text-muted-foreground">{issue.memberName}</p>
                </div>
                <span className="text-xs text-muted-foreground flex-shrink-0">Due: {new Date(issue.dueDate).toLocaleDateString("en-IN")}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Pending Fines */}
        <div className="bg-card border border-card-border rounded-xl shadow-sm">
          <div className="px-5 py-4 border-b border-border flex items-center justify-between">
            <h3 className="font-semibold text-foreground text-sm">Pending Fines</h3>
            <span className="text-xs text-muted-foreground">{pendingFines.length} records</span>
          </div>
          <div className="divide-y divide-border max-h-64 overflow-y-auto">
            {pendingFines.length === 0 ? (
              <div className="p-6 text-center">
                <CheckCircle size={24} className="mx-auto text-green-500 mb-2" />
                <p className="text-sm text-muted-foreground">No pending fines</p>
              </div>
            ) : pendingFines.map(fine => (
              <div key={fine.id} className="px-5 py-3 flex items-center gap-3" data-testid={`report-fine-${fine.id}`}>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground truncate">{fine.memberName}</p>
                  <p className="text-xs text-muted-foreground truncate">{fine.bookTitle}</p>
                </div>
                <span className="text-sm font-bold text-amber-600 flex-shrink-0">₹{fine.amount.toFixed(0)}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
