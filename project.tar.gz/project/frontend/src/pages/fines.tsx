import { useState } from "react";
import { useListFines, usePayFine, getListFinesQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { IndianRupee, CheckCircle, Clock, Search } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function FinesPage() {
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState<"all" | "pending" | "paid">("all");
  const [paying, setPaying] = useState<number | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const allFines = useListFines();
  const payFine = usePayFine();

  const fineList = (allFines.data ?? []).filter(f => {
    const matchesFilter = filter === "all" || (filter === "paid" ? f.paid : !f.paid);
    const matchesSearch = !search || f.memberName.toLowerCase().includes(search.toLowerCase()) || f.bookTitle.toLowerCase().includes(search.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  const totalPending = (allFines.data ?? []).filter(f => !f.paid).reduce((sum, f) => sum + f.amount, 0);
  const totalCollected = (allFines.data ?? []).filter(f => f.paid).reduce((sum, f) => sum + f.amount, 0);

  const handlePay = (id: number, memberName: string, amount: number) => {
    setPaying(id);
    payFine.mutate({ id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListFinesQueryKey() });
        toast({ title: `Fine of ₹${amount.toFixed(0)} collected from ${memberName}` });
        setPaying(null);
      },
      onError: () => {
        toast({ title: "Failed to process payment", variant: "destructive" });
        setPaying(null);
      },
    });
  };

  return (
    <div className="space-y-5">
      {/* Summary */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-card border border-card-border rounded-xl p-5 shadow-sm">
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Pending Fines</p>
          <p className="text-2xl font-bold text-amber-600 mt-1">₹{totalPending.toFixed(0)}</p>
          <p className="text-xs text-muted-foreground mt-1">{(allFines.data ?? []).filter(f => !f.paid).length} unpaid fine(s)</p>
        </div>
        <div className="bg-card border border-card-border rounded-xl p-5 shadow-sm">
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Total Collected</p>
          <p className="text-2xl font-bold text-green-600 mt-1">₹{totalCollected.toFixed(0)}</p>
          <p className="text-xs text-muted-foreground mt-1">{(allFines.data ?? []).filter(f => f.paid).length} paid fine(s)</p>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3">
        <div className="relative flex-1 min-w-48">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <Input
            data-testid="input-fine-search"
            type="search"
            placeholder="Search by member or book..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <Select value={filter} onValueChange={v => setFilter(v as any)}>
          <SelectTrigger data-testid="select-fine-filter" className="w-40">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Fines</SelectItem>
            <SelectItem value="pending">Pending</SelectItem>
            <SelectItem value="paid">Paid</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Fine List */}
      {allFines.isLoading ? (
        <div className="bg-card border border-card-border rounded-xl overflow-hidden">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="h-16 border-b border-border animate-pulse bg-muted/30 last:border-0" />
          ))}
        </div>
      ) : fineList.length === 0 ? (
        <div className="text-center py-16 bg-card border border-card-border rounded-xl">
          <CheckCircle size={40} className="mx-auto text-green-500 mb-3" />
          <p className="font-medium text-foreground">{filter === "pending" ? "No pending fines" : "No fines found"}</p>
          <p className="text-sm text-muted-foreground mt-1">All members are on time</p>
        </div>
      ) : (
        <div className="bg-card border border-card-border rounded-xl overflow-hidden shadow-sm">
          <table className="w-full">
            <thead className="bg-muted/40 border-b border-border">
              <tr>
                <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wide">Member</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wide hidden md:table-cell">Book</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wide hidden sm:table-cell">Due Date</th>
                <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wide hidden sm:table-cell">Returned</th>
                <th className="text-right px-4 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wide">Amount</th>
                <th className="text-center px-4 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wide">Status</th>
                <th className="px-4 py-3"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {fineList.map(fine => (
                <tr key={fine.id} className="hover:bg-muted/20 transition-colors" data-testid={`row-fine-${fine.id}`}>
                  <td className="px-4 py-3">
                    <p className="text-sm font-medium text-foreground">{fine.memberName}</p>
                  </td>
                  <td className="px-4 py-3 hidden md:table-cell">
                    <p className="text-sm text-muted-foreground truncate max-w-40">{fine.bookTitle}</p>
                  </td>
                  <td className="px-4 py-3 hidden sm:table-cell text-xs text-muted-foreground">{new Date(fine.dueDate).toLocaleDateString("en-IN")}</td>
                  <td className="px-4 py-3 hidden sm:table-cell text-xs text-muted-foreground">{new Date(fine.returnDate).toLocaleDateString("en-IN")}</td>
                  <td className="px-4 py-3 text-right">
                    <span className="text-sm font-bold text-foreground">₹{fine.amount.toFixed(0)}</span>
                  </td>
                  <td className="px-4 py-3 text-center">
                    {fine.paid ? (
                      <span className="inline-flex items-center gap-1 text-xs font-medium text-green-600 bg-green-50 px-2 py-0.5 rounded-full">
                        <CheckCircle size={11} />
                        Paid
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-xs font-medium text-amber-600 bg-amber-50 px-2 py-0.5 rounded-full">
                        <Clock size={11} />
                        Pending
                      </span>
                    )}
                  </td>
                  <td className="px-4 py-3 text-right">
                    {!fine.paid && (
                      <Button
                        size="sm"
                        variant="outline"
                        disabled={paying === fine.id}
                        onClick={() => handlePay(fine.id, fine.memberName, fine.amount)}
                        data-testid={`button-pay-fine-${fine.id}`}
                        className="text-xs"
                      >
                        {paying === fine.id ? "Processing..." : "Collect"}
                      </Button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
