import { useState } from "react";
import { useListMembers, useListBooks, useIssueBook, useListIssues, getListIssuesQueryKey, getListBooksQueryKey, getListMembersQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { BookCheck, Search } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";

const issueSchema = z.object({
  memberId: z.coerce.number().int().min(1, "Select a member"),
  bookId: z.coerce.number().int().min(1, "Select a book"),
});

type IssueFormData = z.infer<typeof issueSchema>;

function StatusBadge({ status }: { status: string }) {
  const map: Record<string, string> = {
    issued: "bg-blue-100 text-blue-700",
    returned: "bg-green-100 text-green-700",
    overdue: "bg-red-100 text-red-700",
  };
  return (
    <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${map[status] ?? "bg-muted text-muted-foreground"}`}>
      {status.charAt(0).toUpperCase() + status.slice(1)}
    </span>
  );
}

export default function IssuePage() {
  const [memberSearch, setMemberSearch] = useState("");
  const [bookSearch, setBookSearch] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const members = useListMembers(memberSearch ? { search: memberSearch } : undefined);
  const books = useListBooks(bookSearch ? { search: bookSearch } : undefined);
  const activeIssues = useListIssues({ status: "issued" });
  const issueBook = useIssueBook();

  const form = useForm<IssueFormData>({
    resolver: zodResolver(issueSchema),
    defaultValues: { memberId: 0, bookId: 0 },
  });

  const onSubmit = (data: IssueFormData) => {
    issueBook.mutate({ data }, {
      onSuccess: (result) => {
        queryClient.invalidateQueries({ queryKey: getListIssuesQueryKey() });
        queryClient.invalidateQueries({ queryKey: getListBooksQueryKey() });
        queryClient.invalidateQueries({ queryKey: getListMembersQueryKey() });
        toast({ title: `"${result.bookTitle}" issued to ${result.memberName}`, description: `Due date: ${new Date(result.dueDate).toLocaleDateString("en-IN")}` });
        form.reset();
        setMemberSearch("");
        setBookSearch("");
      },
      onError: (err: any) => {
        toast({ title: "Failed to issue book", description: err?.message ?? "Please check availability", variant: "destructive" });
      },
    });
  };

  const memberList = members.data ?? [];
  const bookList = (books.data ?? []).filter(b => b.availableCopies > 0);
  const issueList = activeIssues.data ?? [];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Issue Form */}
      <div className="bg-card border border-card-border rounded-xl p-6 shadow-sm">
        <div className="flex items-center gap-2 mb-5">
          <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
            <BookCheck size={16} className="text-primary" />
          </div>
          <h3 className="font-semibold text-foreground">Issue a Book</h3>
        </div>
        <div className="mb-3 p-3 bg-blue-50 border border-blue-100 rounded-lg text-xs text-blue-700">
          Issue period: 14 days. Fine: ₹5 per day after due date.
        </div>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
            <div>
              <label className="text-sm font-medium mb-1.5 block">Search Member</label>
              <div className="relative mb-2">
                <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <Input
                  data-testid="input-member-search-issue"
                  type="search"
                  placeholder="Type member name or roll number..."
                  value={memberSearch}
                  onChange={e => setMemberSearch(e.target.value)}
                  className="pl-9 text-sm"
                />
              </div>
              <FormField
                control={form.control}
                name="memberId"
                render={({ field }) => (
                  <FormItem>
                    <Select value={field.value ? String(field.value) : ""} onValueChange={v => field.onChange(Number(v))}>
                      <FormControl>
                        <SelectTrigger data-testid="select-issue-member">
                          <SelectValue placeholder="Select member" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {memberList.map(m => (
                          <SelectItem key={m.id} value={String(m.id)}>
                            {m.name} ({m.rollNumber})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div>
              <label className="text-sm font-medium mb-1.5 block">Search Book</label>
              <div className="relative mb-2">
                <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <Input
                  data-testid="input-book-search-issue"
                  type="search"
                  placeholder="Type book title or author..."
                  value={bookSearch}
                  onChange={e => setBookSearch(e.target.value)}
                  className="pl-9 text-sm"
                />
              </div>
              <FormField
                control={form.control}
                name="bookId"
                render={({ field }) => (
                  <FormItem>
                    <Select value={field.value ? String(field.value) : ""} onValueChange={v => field.onChange(Number(v))}>
                      <FormControl>
                        <SelectTrigger data-testid="select-issue-book">
                          <SelectValue placeholder="Select available book" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {bookList.map(b => (
                          <SelectItem key={b.id} value={String(b.id)}>
                            {b.title} — {b.author} ({b.availableCopies} copies available)
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <Button type="submit" disabled={issueBook.isPending} className="w-full" data-testid="button-submit-issue">
              {issueBook.isPending ? "Issuing..." : "Issue Book"}
            </Button>
          </form>
        </Form>
      </div>

      {/* Currently Issued */}
      <div className="bg-card border border-card-border rounded-xl shadow-sm">
        <div className="px-5 py-4 border-b border-border">
          <h3 className="font-semibold text-foreground text-sm">Currently Issued Books ({issueList.length})</h3>
        </div>
        {activeIssues.isLoading ? (
          <div className="p-5 space-y-3">
            {Array.from({ length: 4 }).map((_, i) => <div key={i} className="h-14 bg-muted rounded animate-pulse" />)}
          </div>
        ) : issueList.length === 0 ? (
          <div className="p-8 text-center">
            <BookCheck size={28} className="mx-auto text-muted-foreground mb-2" />
            <p className="text-sm text-muted-foreground">No books currently issued</p>
          </div>
        ) : (
          <div className="divide-y divide-border max-h-[500px] overflow-y-auto">
            {issueList.map(issue => (
              <div key={issue.id} className="px-5 py-3.5" data-testid={`row-active-issue-${issue.id}`}>
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-medium text-foreground truncate">{issue.bookTitle}</p>
                    <p className="text-xs text-muted-foreground">{issue.memberName}</p>
                  </div>
                  <StatusBadge status={issue.status} />
                </div>
                <p className="text-xs text-muted-foreground mt-1">Due: {new Date(issue.dueDate).toLocaleDateString("en-IN")}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
