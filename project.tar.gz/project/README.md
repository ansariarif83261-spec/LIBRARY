# Library Management System

A full-stack Library Management System built with React + Vite (frontend) and Express + PostgreSQL (backend).

## Features

- Dashboard with real-time stats and charts
- Member Management (register, search, view history)
- Book Management (add, search, filter by category/availability)
- Issue Book (14-day issue period)
- Return Book with automatic fine calculation (Rs. 5 per day)
- Fines Management (view and collect payments)
- Reports with charts

## Project Structure

```
project/
  frontend/      - React + Vite web app
  backend/       - Express API server
  database/      - Drizzle ORM schema and migrations
  openapi.yaml   - Full API specification
```

## Setup Instructions

### Requirements
- Node.js 18+
- PostgreSQL database
- pnpm (or npm)

### Backend Setup

```bash
cd backend
npm install

# Set environment variables
DATABASE_URL=postgresql://user:password@localhost:5432/library
PORT=8080

npm run build
npm run start
```

### Frontend Setup

```bash
cd frontend
npm install

# Set environment variable (points to your backend)
VITE_API_URL=http://localhost:8080

npm run dev
```

### Database Setup

```bash
cd database
npm install

# Set environment variable
DATABASE_URL=postgresql://user:password@localhost:5432/library

npm run push
```

## Tech Stack

- **Frontend**: React 19, Vite, Tailwind CSS, shadcn/ui, Recharts, React Query, Wouter
- **Backend**: Express 5, TypeScript, Pino (logging)
- **Database**: PostgreSQL, Drizzle ORM, Zod validation
- **API**: REST with OpenAPI spec

## Fine Policy

- Issue period: 14 days
- Late fine: Rs. 5 per day after due date
