import { pgTable, serial, integer, timestamp, numeric, boolean } from "drizzle-orm/pg-core";
import { issuesTable } from "./issues";
import { membersTable } from "./members";

export const finesTable = pgTable("fines", {
  id: serial("id").primaryKey(),
  issueId: integer("issue_id").notNull().references(() => issuesTable.id),
  memberId: integer("member_id").notNull().references(() => membersTable.id),
  amount: numeric("amount", { precision: 10, scale: 2 }).notNull(),
  paid: boolean("paid").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type Fine = typeof finesTable.$inferSelect;
