import { pgTable, serial, integer, timestamp, text, numeric } from "drizzle-orm/pg-core";
import { membersTable } from "./members";
import { booksTable } from "./books";

export const issuesTable = pgTable("issues", {
  id: serial("id").primaryKey(),
  memberId: integer("member_id").notNull().references(() => membersTable.id),
  bookId: integer("book_id").notNull().references(() => booksTable.id),
  issueDate: timestamp("issue_date", { withTimezone: true }).notNull().defaultNow(),
  dueDate: timestamp("due_date", { withTimezone: true }).notNull(),
  returnDate: timestamp("return_date", { withTimezone: true }),
  status: text("status").notNull().default("issued"),
  fineAmount: numeric("fine_amount", { precision: 10, scale: 2 }),
});

export type Issue = typeof issuesTable.$inferSelect;
