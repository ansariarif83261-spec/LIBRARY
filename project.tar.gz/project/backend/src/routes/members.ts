import { Router, type IRouter } from "express";
import { eq, ilike, or } from "drizzle-orm";
import { db, membersTable } from "@workspace/db";
import {
  CreateMemberBody,
  UpdateMemberBody,
  GetMemberParams,
  UpdateMemberParams,
  DeleteMemberParams,
  ListMembersQueryParams,
  ListMembersResponse,
  GetMemberResponse,
  UpdateMemberResponse,
} from "@workspace/api-zod";
import { activityTable } from "@workspace/db";

const router: IRouter = Router();

router.get("/members", async (req, res): Promise<void> => {
  const parsed = ListMembersQueryParams.safeParse(req.query);
  const search = parsed.success ? parsed.data.search : undefined;

  let members;
  if (search) {
    members = await db
      .select()
      .from(membersTable)
      .where(
        or(
          ilike(membersTable.name, `%${search}%`),
          ilike(membersTable.rollNumber, `%${search}%`),
          ilike(membersTable.classDepartment, `%${search}%`)
        )
      )
      .orderBy(membersTable.createdAt);
  } else {
    members = await db.select().from(membersTable).orderBy(membersTable.createdAt);
  }

  res.json(ListMembersResponse.parse(members.map(m => ({ ...m, createdAt: m.createdAt.toISOString() }))));
});

router.post("/members", async (req, res): Promise<void> => {
  const parsed = CreateMemberBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [member] = await db.insert(membersTable).values(parsed.data).returning();

  await db.insert(activityTable).values({
    type: "member_added",
    description: `New member registered: ${member.name} (${member.rollNumber})`,
  });

  res.status(201).json(GetMemberResponse.parse({ ...member, createdAt: member.createdAt.toISOString() }));
});

router.get("/members/:id", async (req, res): Promise<void> => {
  const params = GetMemberParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [member] = await db.select().from(membersTable).where(eq(membersTable.id, params.data.id));

  if (!member) {
    res.status(404).json({ error: "Member not found" });
    return;
  }

  res.json(GetMemberResponse.parse({ ...member, createdAt: member.createdAt.toISOString() }));
});

router.put("/members/:id", async (req, res): Promise<void> => {
  const params = UpdateMemberParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = UpdateMemberBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [member] = await db
    .update(membersTable)
    .set(parsed.data)
    .where(eq(membersTable.id, params.data.id))
    .returning();

  if (!member) {
    res.status(404).json({ error: "Member not found" });
    return;
  }

  res.json(UpdateMemberResponse.parse({ ...member, createdAt: member.createdAt.toISOString() }));
});

router.delete("/members/:id", async (req, res): Promise<void> => {
  const params = DeleteMemberParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [member] = await db
    .delete(membersTable)
    .where(eq(membersTable.id, params.data.id))
    .returning();

  if (!member) {
    res.status(404).json({ error: "Member not found" });
    return;
  }

  res.sendStatus(204);
});

export default router;
