import { Router, type IRouter } from "express";
import { eq, and } from "drizzle-orm";
import { db, membersTable, booksTable, issuesTable, finesTable, activityTable } from "@workspace/db";
import {
  IssueBookBody,
  ReturnBookParams,
  ListIssuesQueryParams,
  ListIssuesResponse,
  ReturnBookResponse,
} from "@workspace/api-zod";

const FINE_PER_DAY = 5;

const router: IRouter = Router();

router.get("/issues", async (req, res): Promise<void> => {
  const parsed = ListIssuesQueryParams.safeParse(req.query);
  const memberId = parsed.success ? parsed.data.memberId : undefined;
  const status = parsed.success ? parsed.data.status : undefined;

  const conditions = [];
  if (memberId) conditions.push(eq(issuesTable.memberId, memberId));
  if (status) conditions.push(eq(issuesTable.status, status));

  const issues = await db.select().from(issuesTable).orderBy(issuesTable.issueDate);

  const filtered = conditions.length > 0
    ? issues.filter(i => {
        let match = true;
        if (memberId) match = match && i.memberId === memberId;
        if (status) match = match && i.status === status;
        return match;
      })
    : issues;

  const memberIds = [...new Set(filtered.map(i => i.memberId))];
  const bookIds = [...new Set(filtered.map(i => i.bookId))];

  const members = memberIds.length > 0
    ? await db.select({ id: membersTable.id, name: membersTable.name }).from(membersTable)
    : [];
  const books = bookIds.length > 0
    ? await db.select({ id: booksTable.id, title: booksTable.title, author: booksTable.author }).from(booksTable)
    : [];

  const memberMap = Object.fromEntries(members.map(m => [m.id, m.name]));
  const bookMap = Object.fromEntries(books.map(b => [b.id, { title: b.title, author: b.author }]));

  const result = filtered.map(issue => ({
    id: issue.id,
    memberId: issue.memberId,
    bookId: issue.bookId,
    memberName: memberMap[issue.memberId] ?? "Unknown",
    bookTitle: bookMap[issue.bookId]?.title ?? "Unknown",
    bookAuthor: bookMap[issue.bookId]?.author ?? "Unknown",
    issueDate: issue.issueDate.toISOString(),
    dueDate: issue.dueDate.toISOString(),
    returnDate: issue.returnDate ? issue.returnDate.toISOString() : null,
    status: issue.status,
    fineAmount: issue.fineAmount ? parseFloat(issue.fineAmount) : null,
  }));

  res.json(ListIssuesResponse.parse(result));
});

router.post("/issues", async (req, res): Promise<void> => {
  const parsed = IssueBookBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { memberId, bookId } = parsed.data;

  const [member] = await db.select().from(membersTable).where(eq(membersTable.id, memberId));
  if (!member) {
    res.status(404).json({ error: "Member not found" });
    return;
  }

  const [book] = await db.select().from(booksTable).where(eq(booksTable.id, bookId));
  if (!book) {
    res.status(404).json({ error: "Book not found" });
    return;
  }

  if (book.availableCopies < 1) {
    res.status(400).json({ error: "No copies available" });
    return;
  }

  const issueDate = new Date();
  const dueDate = new Date(issueDate);
  dueDate.setDate(dueDate.getDate() + 14);

  const [issue] = await db.insert(issuesTable).values({
    memberId,
    bookId,
    issueDate,
    dueDate,
    status: "issued",
  }).returning();

  await db.update(booksTable)
    .set({ availableCopies: book.availableCopies - 1 })
    .where(eq(booksTable.id, bookId));

  await db.update(membersTable)
    .set({ booksIssued: member.booksIssued + 1 })
    .where(eq(membersTable.id, memberId));

  await db.insert(activityTable).values({
    type: "issued",
    description: `"${book.title}" issued to ${member.name}`,
  });

  res.status(201).json({
    id: issue.id,
    memberId: issue.memberId,
    bookId: issue.bookId,
    memberName: member.name,
    bookTitle: book.title,
    bookAuthor: book.author,
    issueDate: issue.issueDate.toISOString(),
    dueDate: issue.dueDate.toISOString(),
    returnDate: null,
    status: issue.status,
    fineAmount: null,
  });
});

router.post("/issues/:id/return", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.id) ? req.params.id[0] : req.params.id;
  const id = parseInt(raw, 10);
  if (isNaN(id)) {
    res.status(400).json({ error: "Invalid issue id" });
    return;
  }

  const [issue] = await db.select().from(issuesTable).where(eq(issuesTable.id, id));
  if (!issue) {
    res.status(404).json({ error: "Issue not found" });
    return;
  }

  if (issue.status === "returned") {
    res.status(400).json({ error: "Book already returned" });
    return;
  }

  const returnDate = new Date();
  const dueDate = issue.dueDate;
  let fineAmount = 0;

  if (returnDate > dueDate) {
    const daysLate = Math.ceil((returnDate.getTime() - dueDate.getTime()) / (1000 * 60 * 60 * 24));
    fineAmount = daysLate * FINE_PER_DAY;
  }

  const [updatedIssue] = await db.update(issuesTable)
    .set({
      returnDate,
      status: "returned",
      fineAmount: fineAmount > 0 ? fineAmount.toString() : null,
    })
    .where(eq(issuesTable.id, id))
    .returning();

  const [book] = await db.select().from(booksTable).where(eq(booksTable.id, issue.bookId));
  const [member] = await db.select().from(membersTable).where(eq(membersTable.id, issue.memberId));

  if (book) {
    await db.update(booksTable)
      .set({ availableCopies: book.availableCopies + 1 })
      .where(eq(booksTable.id, issue.bookId));
  }

  if (member) {
    await db.update(membersTable)
      .set({ booksIssued: Math.max(0, member.booksIssued - 1) })
      .where(eq(membersTable.id, issue.memberId));
  }

  if (fineAmount > 0 && member && book) {
    await db.insert(finesTable).values({
      issueId: issue.id,
      memberId: issue.memberId,
      amount: fineAmount.toString(),
      paid: false,
    });
  }

  await db.insert(activityTable).values({
    type: "returned",
    description: `"${book?.title ?? "Book"}" returned by ${member?.name ?? "Member"}${fineAmount > 0 ? ` (Fine: ₹${fineAmount})` : ""}`,
  });

  res.json({
    id: updatedIssue.id,
    memberId: updatedIssue.memberId,
    bookId: updatedIssue.bookId,
    memberName: member?.name ?? "Unknown",
    bookTitle: book?.title ?? "Unknown",
    bookAuthor: book?.author ?? "Unknown",
    issueDate: updatedIssue.issueDate.toISOString(),
    dueDate: updatedIssue.dueDate.toISOString(),
    returnDate: updatedIssue.returnDate ? updatedIssue.returnDate.toISOString() : null,
    status: updatedIssue.status,
    fineAmount: updatedIssue.fineAmount ? parseFloat(updatedIssue.fineAmount) : null,
  });
});

export default router;
