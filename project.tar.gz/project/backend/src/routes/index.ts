import { Router, type IRouter } from "express";
import healthRouter from "./health";
import membersRouter from "./members";
import booksRouter from "./books";
import issuesRouter from "./issues";
import finesRouter from "./fines";
import reportsRouter from "./reports";

const router: IRouter = Router();

router.use(healthRouter);
router.use(membersRouter);
router.use(booksRouter);
router.use(issuesRouter);
router.use(finesRouter);
router.use(reportsRouter);

export default router;
