import { Router, type IRouter } from "express";
import { eq, ilike, or, and } from "drizzle-orm";
import { db, booksTable } from "@workspace/db";
import { activityTable } from "@workspace/db";
import {
  CreateBookBody,
  UpdateBookBody,
  GetBookParams,
  UpdateBookParams,
  DeleteBookParams,
  ListBooksQueryParams,
  ListBooksResponse,
  GetBookResponse,
  UpdateBookResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/books", async (req, res): Promise<void> => {
  const parsed = ListBooksQueryParams.safeParse(req.query);
  const search = parsed.success ? parsed.data.search : undefined;
  const category = parsed.success ? parsed.data.category : undefined;
  const available = parsed.success ? parsed.data.available : undefined;

  const conditions = [];
  if (search) {
    conditions.push(
      or(
        ilike(booksTable.title, `%${search}%`),
        ilike(booksTable.author, `%${search}%`),
        ilike(booksTable.bookId, `%${search}%`)
      )
    );
  }
  if (category) {
    conditions.push(eq(booksTable.category, category));
  }

  let books;
  if (conditions.length > 0) {
    books = await db
      .select()
      .from(booksTable)
      .where(conditions.length === 1 ? conditions[0] : and(...(conditions as [ReturnType<typeof eq>, ...ReturnType<typeof eq>[]])))
      .orderBy(booksTable.createdAt);
  } else {
    books = await db.select().from(booksTable).orderBy(booksTable.createdAt);
  }

  let filtered = books;
  if (available !== undefined) {
    filtered = books.filter(b => available ? b.availableCopies > 0 : b.availableCopies === 0);
  }

  res.json(ListBooksResponse.parse(filtered.map(b => ({ ...b, createdAt: b.createdAt.toISOString() }))));
});

router.post("/books", async (req, res): Promise<void> => {
  const parsed = CreateBookBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { totalCopies, ...rest } = parsed.data;
  const [book] = await db.insert(booksTable).values({
    ...rest,
    totalCopies,
    availableCopies: totalCopies,
  }).returning();

  await db.insert(activityTable).values({
    type: "book_added",
    description: `New book added: "${book.title}" by ${book.author}`,
  });

  res.status(201).json(GetBookResponse.parse({ ...book, createdAt: book.createdAt.toISOString() }));
});

router.get("/books/:id", async (req, res): Promise<void> => {
  const params = GetBookParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [book] = await db.select().from(booksTable).where(eq(booksTable.id, params.data.id));

  if (!book) {
    res.status(404).json({ error: "Book not found" });
    return;
  }

  res.json(GetBookResponse.parse({ ...book, createdAt: book.createdAt.toISOString() }));
});

router.put("/books/:id", async (req, res): Promise<void> => {
  const params = UpdateBookParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = UpdateBookBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [book] = await db
    .update(booksTable)
    .set(parsed.data)
    .where(eq(booksTable.id, params.data.id))
    .returning();

  if (!book) {
    res.status(404).json({ error: "Book not found" });
    return;
  }

  res.json(UpdateBookResponse.parse({ ...book, createdAt: book.createdAt.toISOString() }));
});

router.delete("/books/:id", async (req, res): Promise<void> => {
  const params = DeleteBookParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [book] = await db
    .delete(booksTable)
    .where(eq(booksTable.id, params.data.id))
    .returning();

  if (!book) {
    res.status(404).json({ error: "Book not found" });
    return;
  }

  res.sendStatus(204);
});

export default router;
