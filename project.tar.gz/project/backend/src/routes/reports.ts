import { Router, type IRouter } from "express";
import { eq, sql, count } from "drizzle-orm";
import { db, membersTable, booksTable, issuesTable, finesTable, activityTable } from "@workspace/db";
import {
  GetReportSummaryResponse,
  GetOverdueReportResponse,
  GetActivityReportResponse,
  GetCategoryStatsResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/reports/summary", async (_req, res): Promise<void> => {
  const [{ totalBooks }] = await db.select({ totalBooks: sql<number>`coalesce(sum(${booksTable.totalCopies}), 0)` }).from(booksTable);
  const [{ availableBooks }] = await db.select({ availableBooks: sql<number>`coalesce(sum(${booksTable.availableCopies}), 0)` }).from(booksTable);

  const [{ totalMembers }] = await db.select({ totalMembers: sql<number>`count(*)` }).from(membersTable);
  const [{ activeMembers }] = await db.select({ activeMembers: sql<number>`count(*)` }).from(membersTable).where(sql`${membersTable.booksIssued} > 0`);

  const [{ totalFinesCollected }] = await db.select({ totalFinesCollected: sql<number>`coalesce(sum(${finesTable.amount}), 0)` }).from(finesTable).where(eq(finesTable.paid, true));
  const [{ pendingFines }] = await db.select({ pendingFines: sql<number>`coalesce(sum(${finesTable.amount}), 0)` }).from(finesTable).where(eq(finesTable.paid, false));

  const now = new Date();
  const overdueIssues = await db.select().from(issuesTable).where(eq(issuesTable.status, "issued"));
  const overdueBooks = overdueIssues.filter(i => i.dueDate < now).length;

  const issuedBooks = Number(totalBooks) - Number(availableBooks);

  res.json(GetReportSummaryResponse.parse({
    totalBooks: Number(totalBooks),
    availableBooks: Number(availableBooks),
    issuedBooks: Math.max(0, issuedBooks),
    totalMembers: Number(totalMembers),
    activeMembers: Number(activeMembers),
    totalFinesCollected: parseFloat(String(totalFinesCollected)) || 0,
    pendingFines: parseFloat(String(pendingFines)) || 0,
    overdueBooks,
  }));
});

router.get("/reports/overdue", async (_req, res): Promise<void> => {
  const now = new Date();
  const allIssued = await db.select().from(issuesTable).where(eq(issuesTable.status, "issued"));
  const overdue = allIssued.filter(i => i.dueDate < now);

  const members = await db.select({ id: membersTable.id, name: membersTable.name }).from(membersTable);
  const books = await db.select({ id: booksTable.id, title: booksTable.title, author: booksTable.author }).from(booksTable);

  const memberMap = Object.fromEntries(members.map(m => [m.id, m.name]));
  const bookMap = Object.fromEntries(books.map(b => [b.id, { title: b.title, author: b.author }]));

  await db.update(issuesTable)
    .set({ status: "overdue" })
    .where(sql`${issuesTable.status} = 'issued' AND ${issuesTable.dueDate} < ${now}`);

  const result = overdue.map(issue => ({
    id: issue.id,
    memberId: issue.memberId,
    bookId: issue.bookId,
    memberName: memberMap[issue.memberId] ?? "Unknown",
    bookTitle: bookMap[issue.bookId]?.title ?? "Unknown",
    bookAuthor: bookMap[issue.bookId]?.author ?? "Unknown",
    issueDate: issue.issueDate.toISOString(),
    dueDate: issue.dueDate.toISOString(),
    returnDate: null,
    status: "overdue" as const,
    fineAmount: null,
  }));

  res.json(GetOverdueReportResponse.parse(result));
});

router.get("/reports/activity", async (_req, res): Promise<void> => {
  const activities = await db
    .select()
    .from(activityTable)
    .orderBy(sql`${activityTable.timestamp} desc`)
    .limit(20);

  res.json(GetActivityReportResponse.parse(activities.map(a => ({
    id: a.id,
    type: a.type,
    description: a.description,
    timestamp: a.timestamp.toISOString(),
  }))));
});

router.get("/reports/category-stats", async (_req, res): Promise<void> => {
  const books = await db.select().from(booksTable);

  const categoryMap: Record<string, { totalBooks: number; availableBooks: number }> = {};
  for (const book of books) {
    if (!categoryMap[book.category]) {
      categoryMap[book.category] = { totalBooks: 0, availableBooks: 0 };
    }
    categoryMap[book.category].totalBooks += book.totalCopies;
    categoryMap[book.category].availableBooks += book.availableCopies;
  }

  const result = Object.entries(categoryMap).map(([category, stats]) => ({
    category,
    totalBooks: stats.totalBooks,
    availableBooks: stats.availableBooks,
    issuedBooks: stats.totalBooks - stats.availableBooks,
  }));

  res.json(GetCategoryStatsResponse.parse(result));
});

export default router;
