import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, finesTable, membersTable, booksTable, issuesTable, activityTable } from "@workspace/db";
import {
  ListFinesQueryParams,
  ListFinesResponse,
  PayFineParams,
  PayFineResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/fines", async (req, res): Promise<void> => {
  const parsed = ListFinesQueryParams.safeParse(req.query);
  const memberId = parsed.success ? parsed.data.memberId : undefined;
  const paid = parsed.success ? parsed.data.paid : undefined;

  const allFines = await db.select().from(finesTable).orderBy(finesTable.createdAt);

  const filtered = allFines.filter(f => {
    let match = true;
    if (memberId !== undefined) match = match && f.memberId === memberId;
    if (paid !== undefined) match = match && f.paid === paid;
    return match;
  });

  const memberIds = [...new Set(filtered.map(f => f.memberId))];
  const issueIds = [...new Set(filtered.map(f => f.issueId))];

  const members = await db.select({ id: membersTable.id, name: membersTable.name }).from(membersTable);
  const issues = await db.select({ id: issuesTable.id, bookId: issuesTable.bookId, dueDate: issuesTable.dueDate, returnDate: issuesTable.returnDate }).from(issuesTable);
  const books = await db.select({ id: booksTable.id, title: booksTable.title }).from(booksTable);

  const memberMap = Object.fromEntries(members.map(m => [m.id, m.name]));
  const bookMap = Object.fromEntries(books.map(b => [b.id, b.title]));
  const issueMap = Object.fromEntries(issues.map(i => [i.id, i]));

  const result = filtered.map(f => {
    const issue = issueMap[f.issueId];
    return {
      id: f.id,
      issueId: f.issueId,
      memberId: f.memberId,
      memberName: memberMap[f.memberId] ?? "Unknown",
      bookTitle: issue ? (bookMap[issue.bookId] ?? "Unknown") : "Unknown",
      dueDate: issue ? issue.dueDate.toISOString() : new Date().toISOString(),
      returnDate: issue?.returnDate ? issue.returnDate.toISOString() : new Date().toISOString(),
      amount: parseFloat(f.amount),
      paid: f.paid,
      createdAt: f.createdAt.toISOString(),
    };
  });

  res.json(ListFinesResponse.parse(result));
});

router.post("/fines/:id/pay", async (req, res): Promise<void> => {
  const params = PayFineParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [fine] = await db.select().from(finesTable).where(eq(finesTable.id, params.data.id));
  if (!fine) {
    res.status(404).json({ error: "Fine not found" });
    return;
  }

  if (fine.paid) {
    res.status(400).json({ error: "Fine already paid" });
    return;
  }

  const [updatedFine] = await db.update(finesTable)
    .set({ paid: true })
    .where(eq(finesTable.id, params.data.id))
    .returning();

  const [issue] = await db.select().from(issuesTable).where(eq(issuesTable.id, fine.issueId));
  const [book] = issue ? await db.select().from(booksTable).where(eq(booksTable.id, issue.bookId)) : [undefined];
  const [member] = await db.select().from(membersTable).where(eq(membersTable.id, fine.memberId));

  await db.insert(activityTable).values({
    type: "fine_paid",
    description: `Fine of ₹${parseFloat(fine.amount)} paid by ${member?.name ?? "Member"} for "${book?.title ?? "Book"}"`,
  });

  res.json(PayFineResponse.parse({
    id: updatedFine.id,
    issueId: updatedFine.issueId,
    memberId: updatedFine.memberId,
    memberName: member?.name ?? "Unknown",
    bookTitle: book?.title ?? "Unknown",
    dueDate: issue ? issue.dueDate.toISOString() : new Date().toISOString(),
    returnDate: issue?.returnDate ? issue.returnDate.toISOString() : new Date().toISOString(),
    amount: parseFloat(updatedFine.amount),
    paid: updatedFine.paid,
    createdAt: updatedFine.createdAt.toISOString(),
  }));
});

export default router;
